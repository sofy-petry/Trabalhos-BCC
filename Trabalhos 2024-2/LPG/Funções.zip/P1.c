#include <stdio.h>

int tipo_triangulo(float x, float y, float z) {
    if (x + y <= z || x + z <= y || y + z <= x) {
        return 0;  
    }
    if (x == y && y == z) {
        return 1;  
    }
    if (x == y || x == z || y == z) {
        return 2; 
    }
    return 3;  
}

int main() {
    float lado1, lado2, lado3;

    printf("Digite os três lados do triângulo: ");
    scanf("%f %f %f", &lado1, &lado2, &lado3);

    int resultado = tipo_triangulo(lado1, lado2, lado3);

    switch (resultado) {
        case 0:
            printf("Os lados não formam um triângulo.\n");
            break;
        case 1:
            printf("Triângulo equilátero.\n");
            break;
        case 2:
            printf("Triângulo isósceles.\n");
            break;
        case 3:
            printf("Triângulo escaleno.\n");
            break;
    }

    return 0;
}
