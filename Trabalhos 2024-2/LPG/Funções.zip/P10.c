#include <stdio.h>
long long fatorial_iterativo(int n) {
    long long fat = 1;
    for (int i = 1; i <= n; i++) {
        fat *= i;
    }
    return fat;
}

double calcula_e_iterativo(int n) {
    double e = 1.0; 
    for (int i = 1; i <= n; i++) {
        e += 1.0 / fatorial_iterativo(i); 
    }
    return e;
}

long long fatorial_recursivo(int n) {
    if (n == 0 || n == 1) {
        return 1; 
    }
    return n * fatorial_recursivo(n - 1); 
}
double calcula_e_recursivo(int n) {
    if (n == 0) {
        return 1.0;  
    }
    return (1.0 / fatorial_recursivo(n)) + calcula_e_recursivo(n - 1); 
}

int main() {
    int n;

    printf("Digite o valor de n: ");
    scanf("%d", &n);

    printf("Valor de e (iterativo) para n = %d: %.10lf\n", n, calcula_e_iterativo(n));
    printf("Valor de e (recursivo) para n = %d: %.10lf\n", n, calcula_e_recursivo(n));

    return 0;
}
