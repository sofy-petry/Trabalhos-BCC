#include <stdio.h>

int soma_impares(int x, int y) {
    int soma = 0;

    if (x > y) {
        int temp = x;
        x = y;
        y = temp;
    }
    x++;

    for (int i = x; i < y; i++) {
        if (i % 2 != 0) { 
            soma += i;
        }
    }

    return soma;
}

int main() {
    int x, y;

    printf("Digite dois valores inteiros (x e y): ");
    scanf("%d %d", &x, &y);

    printf("A soma dos números ímpares entre %d e %d é: %d\n", x, y, soma_impares(x, y));

    return 0;
}
