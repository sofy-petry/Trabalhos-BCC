#include <stdio.h>

double soma_harmonica_iterativa(int n) {
    double soma = 0.0;
    for (int i = 1; i <= n; i++) {
        soma += 1.0 / i;
    }
    return soma;
}
double soma_harmonica_recursiva(int n) {
    if (n == 1) {
        return 1.0;  
    }
    return (1.0 / n) + soma_harmonica_recursiva(n - 1); 
}

int main() {
    int n;
    printf("Digite o valor de n: ");
    scanf("%d", &n);
    printf("Soma harmônica iterativa: %.6lf\n", soma_harmonica_iterativa(n));
    printf("Soma harmônica recursiva: %.6lf\n", soma_harmonica_recursiva(n));

    return 0;
}
