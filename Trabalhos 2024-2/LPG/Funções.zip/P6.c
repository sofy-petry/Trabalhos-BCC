#include <stdio.h>

int fibo(int n) {
    if (n == 1 || n == 2) {
        return 1;  
    }
    int a = 1, b = 1, proximo;
    for (int i = 3; i <= n; i++) {
        proximo = a + b;
        a = b;
        b = proximo;
    }
    return b;  
}

int main() {
    int n;
    printf("Digite o valor de n (número de termos da sequência Fibonacci): ");
    scanf("%d", &n);
    printf("Os %d primeiros termos da sequência de Fibonacci são:\n", n);
    for (int i = 1; i <= n; i++) {
        printf("%d ", fibo(i));
    }
    printf("\n");

    return 0;
}
