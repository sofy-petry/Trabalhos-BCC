#include <stdio.h>
#include <ctype.h>  

int e_digito(char c) {
    return isdigit(c);  
}

int main() {
    char caractere;
    int valor_inteiro;

    printf("Digite um caractere: ");
    scanf(" %c", &caractere);

    if (e_digito(caractere)) {
        valor_inteiro = caractere - '0';
        printf("O caractere '%c' é um dígito e seu valor inteiro é: %d\n", caractere, valor_inteiro);
    } else {
        printf("O caractere '%c' não é um dígito.\n", caractere);
    }

    return 0;
}
