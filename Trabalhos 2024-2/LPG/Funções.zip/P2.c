#include <stdio.h>

int maior_valor(int a, int b, int c) {
    int maior = a;  

    if (b > maior) {
        maior = b;  
    }
    if (c > maior) {
        maior = c;  
    }
    return maior;  
}

int main() {
    int x, y, z;

    printf("Digite três valores inteiros: ");
    scanf("%d %d %d", &x, &y, &z);

    printf("O maior valor é: %d\n", maior_valor(x, y, z));

    return 0;
}
