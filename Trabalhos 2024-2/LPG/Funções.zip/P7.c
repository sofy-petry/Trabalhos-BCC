#include <stdio.h>

int soma_especial(int n, int k, int x) {
    int soma = 0;
    int contador = 0;
    int atual = x + 1;  
    while (contador < n) {
        if (atual % k == 0) {  
            soma += atual;     
            contador++;       
        }
        atual++;  
    }
    return soma;
}

int main() {
    int n, k, x;
    printf("Digite o valor de n (número de múltiplos): ");
    scanf("%d", &n);
    printf("Digite o valor de k (múltiplo): ");
    scanf("%d", &k);
    printf("Digite o valor de x (valor inicial): ");
    scanf("%d", &x);

    printf("A soma dos %d múltiplos de %d a partir de %d é: %d\n", n, k, x, soma_especial(n, k, x));

    return 0;
}
