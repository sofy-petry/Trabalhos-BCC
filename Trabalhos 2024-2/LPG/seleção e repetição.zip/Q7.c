#include <stdio.h>

int valor_soma(int x, int y) {
    int soma = 0;

    if (x > y) {
        int temp = x;
        x = y;
        y = temp;
    }

    for (int i = x + 1; i < y; i++) {
        if (i % 2 != 0) {
            soma += i;
        }
    }
    return soma;
}

int main() {
    int N;
    int X, Y;

    scanf("%d", &N);
    int res[N];

    for (int i = 0; i < N; i++) {
        scanf("%d %d", &X, &Y);
 
        res[i] = valor_soma(X, Y);
    }

        for(int j=0; j<N; j++){
        printf("%d\n", res[j]);
        }
        
    return 0;
}

