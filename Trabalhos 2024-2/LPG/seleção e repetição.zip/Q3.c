#include <stdio.h>
#include <math.h>
#include <stdlib.h>


int main(){
 int start, end, i;
 int horas = 0;
 scanf("%d %d", &start, &end);
 if( start < end) horas = end - start;
 else if (start > end ) horas = (24 - start) + end;
 else horas = 24;
 printf("O JOGO DUROU %d HORA(S)", horas);

    return 0;
}