#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include <stdbool.h>

int main() {
    int N;
    float v[3];
    float media[3];

    scanf("%d", &N);
    
    for(int i = 0; i < N; i++) {

        for(int j = 0; j < 3; j++) {
            scanf("%f", &v[j]);
        }
        
        media[i] = (2*v[0] + 3*v[1] + 5*v[2]) / 10;

    }
        for(int p=0; p<3; p++){
        printf("%.1f\n", media[p]);}
    
    return 0;
}