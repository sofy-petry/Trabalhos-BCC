#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include <stdbool.h>

int main(){
 int N, valor;
 int par =0, impar =0, pos= 0, neg = 0;
 scanf("%d", &N);
 for(int i=0; i< N; i++){
    scanf("%d", &valor);
    if (valor%2 !=0 ) impar++;
    else par++;

    if(valor<0)neg++;
    else pos++;
 }
 printf("%d valor(es) par(e)s\n", par);
 printf("%d valor(es) impar(e)s\n", impar);
 printf("%d valor(es) negativo(s)\n", neg);
printf("%d valor(es) positivo(s)\n", pos);


 
    return 0;
}