#include <stdio.h>
#include <math.h>
#include <stdlib.h>


int main(){
   float a,b,c;
   scanf("%f %f %f", &a, &b, &c);
   if (a>= b+c ) printf("NAO FORMA TRIANGULO\n");
   if(a*a == b*b + c*c) printf("TRIANGULO RETANGULO\n");
   if (a*a < b*b + c*c) printf("TRIANGULO ACUTANGULO\n");
   if(a*a > b*b + c*c) printf("TRIANGULO OBTUSANGULO\n");
   if (a==b && a==c) printf("EQUILATERO");
   else if (a!= b && a!= c && c!= b) printf("ESCALENO");
   else printf("ISOSCELES");

    
    return 0;
}