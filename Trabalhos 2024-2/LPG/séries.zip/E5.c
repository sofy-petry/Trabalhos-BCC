#include <stdio.h>

long double fatorial(int num) {
    long double f = 1.0;
    for (int i = 1; i <= num; i++) {
        f *= i;
    }
    return f;
}

long double exp_taylor(double x, int termos) {
    long double resultado = 1.0;  
    long double termo = 1.0;      

    for (int n = 1; n < termos; n++) {
        termo *= x / n;           
        resultado += termo;      
    }

    return resultado;
}

int main() {
    double x;
    int n;

    printf("Digite o valor de x: ");
    scanf("%lf", &x);
    printf("Digite a quantidade de termos da série: ");
    scanf("%d", &n);

    long double resultado = exp_taylor(x, n);

    printf("Aproximacao de e^%.2lf com %d termos: %.15Lf\n", x, n, resultado);

    return 0;
}
