#include <stdio.h>

int main(){
 int n;
 scanf("%d", &n);
 float soma =0;
 printf("1");

 for(int i=1; i<n; i++){
  float q = i+1;
  soma = soma + 1/q;
  printf(" + 1/%1.f", q);
 }

 printf(" = %f", soma);

    return 0;
}
