#include <stdio.h>

int main() {
    int n;
    double pi = 0.0;

    scanf("%d", &n);

    for (int i = 0; i < n; i++) {
        double termo = (i % 2 == 0) ? 1.0 : -1.0;
        pi += termo / (2 * i + 1);
    }

    pi *= 4.0; 

    printf("Aproximacao de pi pela serie de Gregory-Leibniz: %.15f\n", pi);

    return 0;
}
