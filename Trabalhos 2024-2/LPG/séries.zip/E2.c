#include <stdio.h>

int main() {
    int k;
    double soma = 0.0;

    scanf("%d", &k);

    for (int i = 1; i <= k; i++) {
        double termo = 1.0 / i;
        if (i % 2 == 0) {
            termo = -termo;  
        }
        soma += termo;
        printf("Termo %d: %.1f\n", i, termo);
    }

    printf("Somatório dos termos: %.6f\n", soma);

    return 0;
}
