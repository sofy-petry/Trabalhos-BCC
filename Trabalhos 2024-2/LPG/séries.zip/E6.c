#include <stdio.h>

long double potencia(double x, int n) {
    long double resultado = 1.0;
    for (int i = 0; i < n; i++) {
        resultado *= x;
    }
    return resultado;
}

long double fatorial(int num) {
    long double f = 1.0;
    for (int i = 1; i <= num; i++) {
        f *= i;
    }
    return f;
}

long double seno_taylor(double x, int termos) {
    long double resultado = 0.0;

    for (int n = 0; n < termos; n++) {
        int expoente = 2 * n + 1;
        long double termo = potencia(x, expoente) / fatorial(expoente);
        if (n % 2 == 0) {
            resultado += termo;  
        } else {
            resultado -= termo;  
        }
    }

    return resultado;
}

int main() {
    double x;
    int termos;

    printf("Digite o valor de x (em radianos): ");
    scanf("%lf", &x);
    printf("Digite a quantidade de termos da série: ");
    scanf("%d", &termos);

   
    long double resultado = seno_taylor(x, termos);

   
    printf("Aproximacao de seno(%.2lf) com %d termos: %.15Lf\n", x, termos, resultado);

    return 0;
}
