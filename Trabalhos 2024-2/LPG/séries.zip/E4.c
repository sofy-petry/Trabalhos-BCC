#include <stdio.h>

long double fatorial(int num) {
    long double f = 1.0;
    for (int i = 1; i <= num; i++) {
        f *= i;
    }
    return f;
}

int main() {
    int n;
    long double e = 1.0; 

    scanf("%d", &n);

    for (int i = 1; i < n; i++) {
        e += 1.0 / fatorial(i);
    }
    printf("Aproximacao do valor da constante e com %d termos: %.15Lf\n", n, e);
    return 0;
}
