#include <stdio.h>
#include <string.h>

void converte_para_maiusculo(char *s) {
    for(int i = 0; s[i] != '\0'; i++) {
        if(s[i] >= 'a' && s[i] <= 'z') {
            s[i] = s[i] - 32; 
        }
    }
}

int main() {
    char s[100];
    printf("Digite uma string:\n");
    fgets(s, 100, stdin);
    s[strcspn(s, "\n")] = '\0';
    converte_para_maiusculo(s);

    printf("String convertida para maiúsculas: %s\n", s);

    return 0;
}
