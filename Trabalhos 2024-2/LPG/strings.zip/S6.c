#include <stdio.h>

int contem_somente_digitos(const char *s) {
    for(int i = 0; s[i] != '\0'; i++) {
        if(s[i] < '0' || s[i] > '9') {
            return 0; 
        }
    }
    return 1;
}

int main() {
    char s[100];
    printf("Digite uma string:\n");
    fgets(s, 100, stdin);

    s[strcspn(s, "\n")] = '\0';

    if(contem_somente_digitos(s)) {
        printf("A string '%s' contém apenas dígitos.\n", s);
    } else {
        printf("A string '%s' contém caracteres que não são dígitos.\n", s);
    }

    return 0;
}
