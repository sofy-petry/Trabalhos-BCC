#include <stdio.h>

void remove_caractere(char str[], char c) {
    int i, j = 0;
    for (i = 0; str[i] != '\0'; i++) {
        if (str[i] != c) {
            str[j] = str[i];
            j++;
        }
    }
    str[j] = '\0';
}

int main() {
    char s[100];
    char c;

    printf("Digite uma string:\n");
    fgets(s, 100, stdin);
    s[strcspn(s, "\n")] = '\0';

    printf("Digite um caractere a ser removido:\n");
    scanf("%c", &c);
    remove_caractere(s, c);

    printf("String após remover '%c': '%s'\n", c, s);

    return 0;
}
