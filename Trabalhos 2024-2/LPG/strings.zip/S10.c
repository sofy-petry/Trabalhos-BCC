#include <stdio.h>
#include <string.h>


void inverte(char str[]) {
    int inicio = 0;
    int fim = strlen(str) - 1;
    char temp;
    while (inicio < fim) {
        temp = str[inicio];
        str[inicio] = str[fim];
        str[fim] = temp;
        inicio++;
        fim--;
    }
}

int main() {
    char str[100];

    printf("Digite uma string:\n");
    fgets(str, 100, stdin);
    str[strcspn(str, "\n")] = '\0';

    inverte(str);

    printf("String invertida: '%s'\n", str);

    return 0;
}
