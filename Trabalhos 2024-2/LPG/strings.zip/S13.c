#include <stdio.h>
#include <string.h>

void substring(char str[], int ini, int n, char sub[]) {
    int len = strlen(str);
    if (ini >= len || n <= 0) {
        sub[0] = '\0';
        return;
    }
    int i, j = 0;
    for (i = ini; i < len && j < n; i++) {
        sub[j] = str[i];
        j++;
    }
    sub[j] = '\0';
}

int main() {
    char str[100] = "Alguma Coisa 123";
    char sub[100];
    int ini, n;

    printf("Digite o índice inicial:\n");
    scanf("%d", &ini);
    printf("Digite a quantidade de caracteres a copiar:\n");
    scanf("%d", &n);

    substring(str, ini, n, sub);

    printf("Substring resultante: '%s'\n", sub);

    return 0;
}
