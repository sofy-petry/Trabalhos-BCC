#include <stdio.h>

int contem_char(char s[], char c) {
    for(int i = 0; s[i] != '\0'; i++) {
        if(s[i] == c) {
            return 1; 
        }
    }
    return 0; 
}

int main() {
    char s[100], c;
    printf("Digite uma string:\n");
    fgets(s, 100, stdin); 
    
    printf("Digite um caractere:\n");
    scanf(" %c", &c); 
    
    if(contem_char(s, c)) {
        printf("O caractere '%c' está presente.\n", c);
    } else {
        printf("O caractere '%c' não está presente.\n", c);
    }

    return 0;
}
