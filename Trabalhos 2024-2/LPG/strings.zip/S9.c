#include <stdio.h>
#include <string.h>
#include <ctype.h> 

void trim(char str[]) {
    int inicio = 0, fim, i;

    while (isspace((unsigned char)str[inicio])) {
        inicio++;
    }

    if (str[inicio] == '\0') {
        str[0] = '\0';
        return;
    }
    fim = strlen(str) - 1;

    while (fim > inicio && isspace((unsigned char)str[fim])) {
        fim--;
    }

    for (i = 0; i <= fim - inicio; i++) {
        str[i] = str[inicio + i];
    }
    str[i] = '\0'; 
}

int main() {
    char str[100];

    printf("Digite uma string (com espaços):\n");
    fgets(str, 100, stdin);

    str[strcspn(str, "\n")] = '\0';

    trim(str);

    printf("String após o trimming: '%s'\n", str);

    return 0;
}
