#include <stdio.h>

int compara(char str1[], char str2[]) {
    int i = 0;
    while (str1[i] != '\0' && str2[i] != '\0') {

        if (str1[i] != str2[i]) {
            return str1[i] - str2[i];
        }
        i++;
    }
    return str1[i] - str2[i];
}

int main() {
    char str1[100], str2[100];

    printf("Digite a primeira string:\n");
    fgets(str1, 100, stdin);
    str1[strcspn(str1, "\n")] = '\0'; 

    printf("Digite a segunda string:\n");
    fgets(str2, 100, stdin);
    str2[strcspn(str2, "\n")] = '\0'; 

    int resultado = compara(str1, str2);

    if (resultado < 0) {
        printf("'%s' vem antes de '%s'\n", str1, str2);
    } else if (resultado > 0) {
        printf("'%s' vem depois de '%s'\n", str1, str2);
    } else {
        printf("'%s' é igual a '%s'\n", str1, str2);
    }

    return 0;
}
