#include <stdio.h>
#include <ctype.h> 

int formato_valido(const char *data) {
    if (data[2] != '/' || data[5] != '/' || data[10] != '\0') {
        return 0;
    }

    for (int i = 0; i < 10; i++) {
        if (i != 2 && i != 5) {
            if (!isdigit(data[i])) {
                return 0;
            }
        }
    }
    
    return 1;
}

int main() {
    char data[11]; 
    int dia, mes, ano;

    printf("Digite a data no formato DD/MM/AAAA:\n");
    fgets(data, 11, stdin);

    if (formato_valido(data)) {
        
        sscanf(data, "%2d/%2d/%4d", &dia, &mes, &ano);

        printf("Dia: %d\n", dia);
        printf("Mês: %d\n", mes);
        printf("Ano: %d\n", ano);
    } else {
        printf("Formato de data inválido.\n");
    }

    return 0;
}
