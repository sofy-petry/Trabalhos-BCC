#include <stdio.h>

int string_para_inteiro(const char *s) {
    int resultado = 0;
    for (int i = 0; s[i] != '\0'; i++) {
        resultado = resultado * 10 + (s[i] - '0');
    }
    return resultado;
}

int main() {
    char s[100];
    printf("Digite uma string contendo apenas dígitos:\n");
    fgets(s, 100, stdin);

    s[strcspn(s, "\n")] = '\0';

    int valido = 1;
    for (int i = 0; s[i] != '\0'; i++) {
        if (s[i] < '0' || s[i] > '9') {
            valido = 0;
            break;
        }
    }

    if (valido) {
        int numero = string_para_inteiro(s);
        printf("O número inteiro convertido é: %d\n", numero);
    } else {
        printf("A string contém caracteres não numéricos.\n");
    }

    return 0;
}
