#include <stdio.h>

void concatena(char str1[], char str2[]) {
    int i = 0, j = 0;

    while (str1[i] != '\0') {
        i++;
    }

    while (str2[j] != '\0') {
        str1[i] = str2[j];
        i++;
        j++;
    }
    str1[i] = '\0';
}

int main() {
    char str1[200], str2[100];

    printf("Digite a primeira string:\n");
    fgets(str1, 200, stdin);

    printf("Digite a segunda string:\n");
    fgets(str2, 100, stdin);

    for (int i = 0; str1[i] != '\0'; i++) {
        if (str1[i] == '\n') {
            str1[i] = '\0';
            break;
        }
    }
    for (int i = 0; str2[i] != '\0'; i++) {
        if (str2[i] == '\n') {
            str2[i] = '\0';
            break;
        }
    }
    concatena(str1, str2);

    printf("Resultado da concatenacao: %s\n", str1);

    return 0;
}
