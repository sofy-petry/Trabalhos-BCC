#include <stdio.h>

int conta_ocorrencias(char s[], char c) {
    int cont = 0;
    for(int i = 0; s[i] != '\0'; i++) {
        if(s[i] == c) {
            cont++; 
        }
    }
    return cont;
}

int main() {
    char s[100], c;
    printf("Digite uma string:\n");
    fgets(s, 100, stdin); 
    
    printf("Digite um caractere:\n");
    scanf(" %c", &c); 
    
    int ocorrencias = conta_ocorrencias(s, c);

    if(ocorrencias > 0) {
        printf("O caractere '%c' aparece %d vezes na string.\n", c, ocorrencias);
    } else {
        printf("O caractere '%c' não está presente na string.\n", c);
    }

    return 0;
}
