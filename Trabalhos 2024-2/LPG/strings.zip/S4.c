#include <stdio.h>
#include <string.h>

int eh_palindromo(const char *s) {
    int inicio = 0;
    int fim = strlen(s) - 1;

    while (inicio < fim) {
        if (s[inicio] != s[fim]) {
            return 0; 
        }
        inicio++;
        fim--;
    }
    return 1; 
}

int main() {
    char s[100];
    printf("Digite uma string:\n");
    fgets(s, 100, stdin);

    s[strcspn(s, "\n")] = '\0';

    if (eh_palindromo(s)) {
        printf("A string '%s' é um palíndromo.\n", s);
    } else {
        printf("A string '%s' não é um palíndromo.\n", s);
    }

    return 0;
}
