#include <stdio.h>
#include <stdbool.h>

bool eh_primo(int num) {
    if (num <= 1) return false;
    for (int i = 2; i * i <= num; i++) {
        if (num % i == 0) {
            return false;
        }
    }
    return true;
}

int soma_primos(int v[], int n) {
    int soma = 0;
    for (int i = 0; i < n; i++) {
        if (eh_primo(v[i])) {
            soma += v[i]; 
        }
    }
    return soma;
}

int main() {
    int n;
    
    printf("Digite a quantidade de elementos do vetor: ");
    scanf("%d", &n);
    
    int v[n];

    printf("Digite os elementos do vetor:\n");
    for (int i = 0; i < n; i++) {
        scanf("%d", &v[i]);
    }
  
    int soma = soma_primos(v, n);
    
    printf("A soma dos números primos no vetor é: %d\n", soma);
    
    return 0;
}
