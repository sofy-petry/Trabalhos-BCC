#include <stdio.h>

void busca_seq_rec(int v[], int n, int chave, int indices[], int pos) {
    if (n == 0) {
        for (int i = pos; i >= 0; i--) {
            indices[i] = -1;
        }
        return;
    }


    if (v[n - 1] == chave) {
        indices[pos] = n - 1;
        busca_seq_rec(v, n - 1, chave, indices, pos - 1); 
    } else {
        busca_seq_rec(v, n - 1, chave, indices, pos); 
}
}

int main() {
    int n = 10;
    int v[] = {3, 6, 7, -1, 3, 12, 9, 8, 3, 17};
    int chave = 3;
    int indices[n]; 

    for (int i = 0; i < n; i++) {
        indices[i] = -1;
    }

    busca_seq_rec(v, n, chave, indices, n - 1);

    printf("Índices em que a chave se encontra:\n");
    for (int i = 0; i < n; i++) {
        printf("%d ", indices[i]);
    }
    printf("\n");

    return 0;
}
