#include <stdio.h>

void busca_todos(int v[], int n, int chave, int indices[]) {
    int pos = 0; 

    for (int i = 0; i < n; i++) {
        if (v[i] == chave) {
            indices[pos] = i;
            pos++;
        }
    }

    for (int i = pos; i < n; i++) {
        indices[i] = -1;
    }
}

int main() {
    int n = 10;
    int v[] = {3, 6, 7, -1, 3, 12, 9, 8, 3, 17};
    int chave = 3;
    int indices[n]; 
    
    busca_todos(v, n, chave, indices);

    printf("Índices em que a chave se encontra: ");
    for (int i = 0; i < n; i++) {
        printf("%d ", indices[i]);
    }
    printf("\n");
    
    return 0;
}
